package com.example.Employee.Data;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class EmployeeDto {

	@NotEmpty(message="please enter employee Id")
	@Pattern(regexp = "^[a-zA-Z0-9][a-zA-Z.\\s]*$", message ="Please enter only alphabets or numbers")
	private String employeeId;

	@NotEmpty(message="please enter firstName")
	@Pattern(regexp = "^[a-zA-Z][a-zA-Z.\\s]*$", message ="Please enter only alphabets ")
	private String firstName;

	@NotEmpty(message="please enter lastName")
	@Pattern(regexp = "^[a-zA-Z][a-zA-Z.\\s]*$", message ="Please enter only alphabets ")
	private String lastName;

	@NotEmpty(message="please enter email")
	@Pattern(regexp = "^[a-zA-Z][a-zA-Z.@\\s]*$", message ="Please enter only alphabets ")
	private String email;

	@Valid
	@Size(min=1 ,message="At least one phone number is required")
	private List<@Pattern(regexp = "^[6||7||8||9][0-9]+$", message ="Please enter valid mobile number") String> phoneNumbers;

	@NotEmpty(message="please enter dateOFJoining")
	@Pattern(regexp = "[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-3][0-9])", message ="Please enter valid dateOfJoining")
	private String doj;

	@NotEmpty(message="please enter salary")
	@Pattern(regexp = "^[0-9]+$", message ="Please enter valid salary")
	private Double salary;
	
	private Double yearlyTax;
	
	

	public Double getYearlyTax() {
		return yearlyTax;
	}

	public void setYearlyTax(Double yearlyTax) {
		this.yearlyTax = yearlyTax;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public List<String> getPhoneNumbers() {
		return phoneNumbers;
	}

	public void setPhoneNumbers(List<String> phoneNumbers) {
		this.phoneNumbers = phoneNumbers;
	}

	public String getDoj() {
		return doj;
	}

	public void setDoj(String doj) {
		this.doj = doj;
	}

	public Double getSalary() {
		return salary;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "EmployeeDto [employeeId=" + employeeId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", email=" + email + ", phoneNumbers=" + phoneNumbers + ", doj=" + doj + ", salary=" + salary
				+ ", yearlyTax=" + yearlyTax + "]";
	}

	



}
