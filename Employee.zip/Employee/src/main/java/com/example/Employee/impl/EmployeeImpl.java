package com.example.Employee.impl;

import java.time.LocalDate;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Employee.Data.EmployeeDto;
import com.example.Employee.Data.ResponseData;
import com.example.Employee.Data.TaxDeductionResponse;
import com.example.Employee.api.IEmployee;
import com.example.Employee.model.Employee;
import com.example.Employee.repository.EmployeeRepo;

@Service
public class EmployeeImpl implements IEmployee {

	@Autowired
	EmployeeRepo employeeRepo;

	@Override
	public ResponseData saveEmployeeDetails(EmployeeDto employeeDto) {


		Employee emp=new Employee();
		BeanUtils.copyProperties(emp,employeeDto);

		employeeRepo.save(emp);
		return new ResponseData("Employee Details Saved Successfull",200);
	}

	@Override
	 public Optional<Employee> getEmployee(String employeeId) {
	        return employeeRepo.findByEmployeeId(employeeId);
	    }

	@Override
	public TaxDeductionResponse getEmployeeDetails(Employee employee) {
		
		LocalDate startOfFinancialYear = LocalDate.of(LocalDate.now().getYear(), Month.APRIL, 1);
        LocalDate endOfFinancialYear = LocalDate.of(LocalDate.now().getYear() + 1, Month.MARCH, 31);

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate doj = LocalDate.parse(employee.getDoj(), formatter);

        if (doj.isAfter(startOfFinancialYear)) {
            startOfFinancialYear = doj;
        }

        long monthsWorked = ChronoUnit.MONTHS.between(startOfFinancialYear.withDayOfMonth(1), endOfFinancialYear.withDayOfMonth(1)) + 1;
        
        double monthlySalary = employee.getSalary();
        double yearlySalary = monthlySalary * monthsWorked;

        double taxAmount = calculateTaxAmount(yearlySalary);
        double cessAmount = calculateCessAmount(yearlySalary);

        TaxDeductionResponse response = new TaxDeductionResponse();
        response.setEmployeeId(employee.getEmployeeId());
        response.setFirstName(employee.getFirstName());
        response.setLastName(employee.getLastName());
        response.setYearlySalary(yearlySalary);
        response.setTaxAmount(taxAmount);
        response.setCessAmount(cessAmount);

        employee.setYearlyTax(taxAmount + cessAmount);

        return response;
	}
	
	private double calculateTaxAmount(double salary) {
        double taxAmount = 0.0;

        if (salary > 250000) {
            if (salary <= 500000) {
                taxAmount = (salary - 250000) * 0.05;
            } else if (salary <= 1000000) {
                taxAmount = 250000 * 0.05 + (salary - 500000) * 0.10;
            } else {
                taxAmount = 250000 * 0.05 + 500000 * 0.10 + (salary - 1000000) * 0.20;
            }
        }

        return taxAmount;
    }

    private double calculateCessAmount(double salary) {
        double cessAmount = 0.0;

        if (salary > 2500000) {
            cessAmount = (salary - 2500000) * 0.02;
        }

        return cessAmount;
    }

}
