package com.example.Employee.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Employee.Data.EmployeeDto;
import com.example.Employee.Data.EmployeeNotFoundException;
import com.example.Employee.Data.ResponseData;
import com.example.Employee.Data.TaxDeductionResponse;
import com.example.Employee.api.IEmployee;
import com.example.Employee.model.Employee;

@RestController
public class EmployeeConroller {
	
@Autowired
private IEmployee iEmployee;

@PostMapping("/api/employees")
public ResponseData saveEmployeeDetails(@Valid @RequestBody EmployeeDto employeeDto) {
	
	return iEmployee.saveEmployeeDetails(employeeDto);
}

@GetMapping("api/employees/{employeeId}/tax-deductions")
public ResponseEntity<TaxDeductionResponse> getEmployeeDetails(@PathVariable String employeeId) {

	 Employee employee = iEmployee.getEmployee(employeeId)
             .orElseThrow(() -> new EmployeeNotFoundException("Employee not found"));
    TaxDeductionResponse response = iEmployee.getEmployeeDetails(employee);
    return ResponseEntity.ok(response);
}
}

