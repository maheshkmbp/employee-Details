package com.example.Employee.api;

import java.util.List;
import java.util.Optional;

import com.example.Employee.Data.EmployeeDto;
import com.example.Employee.Data.ResponseData;
import com.example.Employee.Data.TaxDeductionResponse;
import com.example.Employee.model.Employee;

public interface IEmployee {
	
	ResponseData saveEmployeeDetails(EmployeeDto employeeDto);
	
	TaxDeductionResponse getEmployeeDetails(Employee emp);
	
	 Optional<Employee> getEmployee(String employeeId);

}
